package com.example.registerloginexample;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.Set;

public class BluetoothActivity extends AppCompatActivity {
    ListView listViewPaired; //페어링된 기기와 연결가능한 목록 보여주는 리스트 뷰
    ListView listViewSearched;
    Button btnSearch; //찾기버튼
    Switch switchOn; //블루투스 기능

    private BluetoothAdapter bluetoothAdapter; //블루투스 어답터 객체
    private ArrayList<BluetoothDevice> arrayListPaired; //찾은 블루투스 가지고 있음
    private ArrayList<String> arrayListPairedName;//리스트뷰 페어드랑 연결,
    private ArrayList<BluetoothDevice> arrayListSearched; //연결 가능한 블루투스 저장
    private ArrayList<String> arrayListSearchedName; //연결가능한 블루투스 이름을 저장하고 있음
    private ArrayAdapter<String> adapterPaired; //리스트뷰 어답터랑 연결
    private ArrayAdapter<String> adapterSearched; //서치드랑 연결
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth); if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && //권한 요청,권한 순서 중요
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN,
                    Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, 100);
            return;
        }

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        initList();
        initOnOff();
        searchPairedDevice();
        searchDevice();
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) { //(3번쨰 매개변수 허용여부 체크)
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode != 100)
            return;
        if(grantResults.length >= 2 && grantResults[0] == PackageManager.PERMISSION_GRANTED //첫번째 권한 허용했는지 , 두번쨰 권한 허용했는지
                && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            initList();
            initOnOff();
            searchPairedDevice();
            searchDevice();
        }
    }
    private void initList() {
        listViewPaired = findViewById(R.id.listPaired);
        listViewSearched = findViewById(R.id.listDevices);
        btnSearch = findViewById(R.id.buttonSearch);

        arrayListPaired = new ArrayList<BluetoothDevice>(); // 디바이스 목록
        arrayListSearched = new ArrayList<BluetoothDevice>();
        arrayListPairedName = new ArrayList<String>(); // 연결가능 디바이스 이름 저장하기위해
        arrayListSearchedName = new ArrayList<String>();
        adapterPaired = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayListPairedName); //어댑터뷰(컨텍스트,뷰레이아웃,목록에 보여줄 데이터 저장하고 있는 어레이리스트)
        adapterSearched = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayListSearchedName);
        listViewPaired.setAdapter(adapterPaired); //어답터 사용할거라고 알려줌
        listViewSearched.setAdapter(adapterSearched);

        listViewPaired.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {  //이벤트처리기 생성,등록 블루투스 연결할 거 길게 눌렀을때 이벤트 발생. 인터페이스
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), ConnecteActivity.class); //커넥트 액티비티로 넘어가서 실행
                BluetoothDevice device = arrayListPaired.get(i); //항목 가져오기
                intent.putExtra("name", device.getName()); //블루투스 이름 가져오기
                intent.putExtra("address", device.getAddress()); // 블루투스 주소 가져오기
                startActivity(intent); //인텐트 사용하기
                return true;
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() { //찾기 버튼
            @Override
            public void onClick(View v) {
                searchPairedDevice();
                searchDevice();
            }
        });

        listViewSearched.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { //연결가능한거 길게 클릭하면 이벤트 실행
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), ConnecteActivity.class);
                BluetoothDevice device = arrayListSearched.get(i);
                intent.putExtra("name", device.getName());
                intent.putExtra("address", device.getAddress());
                startActivity(intent);
                return true;
            }
        });
    } // initList
    private ActivityResultLauncher<Intent> launcher = registerForActivityResult( //런처 생성
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    int resultCode = result.getResultCode();
                    if (resultCode == RESULT_OK) {
                        searchPairedDevice();
                        searchDevice();
                        Toast.makeText(getApplicationContext(), "블루투스 활성화", Toast.LENGTH_LONG).show();
                    } else if (resultCode == RESULT_CANCELED) {
                        Toast.makeText(getApplicationContext(), "취소", Toast.LENGTH_LONG).show();
                        switchOn.setChecked(false);
                    }
                }
            });

    private void initOnOff(){ //스위치 버튼
        switchOn = findViewById(R.id.switchOn);
        switchOn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { //스위치 바꿀때마다 호출
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) { //(버튼,상태값(선택한 상태로 바꾸면 true, 비활성화 하면 false로 넘어감))
                if(b){ //활성화시
                    Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);// 인텐트사용
                    launcher.launch(intent);//런치메소드 호출, 온액티비티리절트
                }else{
                    bluetoothAdapter.disable(); //비활성화
                }
            }
        });//스위치 바꿀때
    }

    private void searchPairedDevice(){
        if(!bluetoothAdapter.isEnabled()) //블루투스가 활성화가 안되어있으면 꺼짐
            return;
        Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices(); // 페어링된 블루투스 정보 저장
        arrayListPaired.clear(); //기존에 있는 페어링된 블루투스 삭제
        arrayListPairedName.clear();
        for(BluetoothDevice device : devices){ //찾아온 블루투스 객체 하나씩 끄집어 내서 저장
            arrayListPaired.add(device);//디바이스추가
            String sName = device.getName(); //디바이스에서 이름 가져와서 저장
            if(sName == null || sName.isEmpty()) //디바이스 이름이 없거나 비어있을때
                sName=device.getAddress(); //디바이스 주소 저장
            arrayListPairedName.add(sName);
        }
        adapterPaired.notifyDataSetChanged(); //보여주기
    }

    BroadcastReceiver receiver = new BroadcastReceiver() { //생성
        @Override
        public void onReceive(Context context, Intent intent) { //추상메소드
            String sAction = intent.getAction();//내가 요청한 파운드에서만 반응을 하기 위해서
            if(sAction.equals(BluetoothDevice.ACTION_FOUND)){
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);//넘겨준거 찾아올게
                if(device == null)
                    return;
                arrayListSearched.add(device);
                String sName = device.getName();
                if(sName == null || sName.isEmpty())
                    sName = device.getAddress();
                arrayListSearchedName.add(sName);
                adapterSearched.notifyDataSetChanged();
            }
        }
    };

    private void searchDevice(){
        if(!bluetoothAdapter.isEnabled()) //블루투스가 활성화가 안되어있으면 꺼짐
            return;
        if(bluetoothAdapter.isDiscovering()) //찾고있는도중이면 캔슬
            bluetoothAdapter.cancelDiscovery();

        arrayListSearched.clear(); //계속 쌓이는거 방지
        arrayListSearchedName.clear();
        adapterSearched.notifyDataSetChanged();

        //검색
        bluetoothAdapter.startDiscovery();
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(receiver,filter);

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }

}