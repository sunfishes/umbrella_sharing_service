package com.example.registerloginexample;

import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.SystemClock;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

class ConnectedThread extends Thread {
    final static int BT_MESSAGE_READ  = 1;
    final static int BT_MESSAGE_ERROR = 2;

    final static UUID BLUETOOTH_UUID_SPP = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb"); //소켓 연결할 때 프로파일 사용해서 uuid만들기

    private BluetoothSocket mmSocket;
    private InputStream mmInStream;
    private OutputStream mmOutStream;
    private Handler mmBluetoothHandler;

    public ConnectedThread(BluetoothSocket socket, Handler handler) { //(소켓, 핸들러)
        mmSocket = socket;
        mmBluetoothHandler = handler;

        try {
            mmInStream = socket.getInputStream(); //데이터 주고받기 위해서
            mmOutStream = socket.getOutputStream();
        } catch (IOException e) { //오류처리
            String sMsg = "소켓 연결 중 오류가 발생했습니다.";
            byte[] buf = sMsg.getBytes();
            mmBluetoothHandler.obtainMessage(BT_MESSAGE_ERROR, buf.length, -1, buf).sendToTarget(); //핸들러객체 이용해서 메인쓰레드에 메세지 보냄
        }
    }

    public void run() { //쓰레드가 해야하는일 작성
        byte[] buffer = new byte[1024];
        int bytes;

        while (true) {
            try {
                bytes = mmInStream.available(); //아두이노가 데이터를 보내는지
                if (bytes != 0) { //있으면 0보다 큰값 리턴
                    SystemClock.sleep(100);
                    bytes = mmInStream.available();
                    bytes = mmInStream.read(buffer, 0, bytes);
                    mmBluetoothHandler.obtainMessage(BT_MESSAGE_READ, bytes, -1, buffer).sendToTarget();//서버에 보내
                }
            } catch (IOException e) {
                String sMsg = "데이터 읽기 중 오류가 발생했습니다.";
                byte[] buf = sMsg.getBytes();
                mmBluetoothHandler.obtainMessage(BT_MESSAGE_ERROR, buf.length, -1, buf).sendToTarget();//서버에 보내
                break;
            }
        }
    }

    public void write(String str) { //핸드폰에서 아두이노로 전송할때
        byte[] bytes = str.getBytes();
        try {
            mmOutStream.write(bytes); //전송
        } catch (IOException e) {
            String sMsg = "데이터 전송 중 오류가 발생했습니다.";
            byte[] buffer = sMsg.getBytes();
            mmBluetoothHandler.obtainMessage(BT_MESSAGE_ERROR, buffer.length, -1, buffer).sendToTarget(); //메인쓰레드로 오류발생하면 메세지 보냄
        }
    }

    public void cancel() { //런이 무한루프를 돌다가 캔슬을 통해서 위에 런메소드로 가서 예외발생시키고 break -> 스레드 종료 역할
        try {
            mmOutStream.close(); //통신중단
            mmInStream.close();
            mmSocket.close();
        } catch (IOException e) {
            String sMsg = "소켓 해제 중 오류가 발생했습니다.";
            byte[] buffer = sMsg.getBytes();
            mmBluetoothHandler.obtainMessage(BT_MESSAGE_ERROR, buffer.length, -1, buffer).sendToTarget();
        }
    }
}
