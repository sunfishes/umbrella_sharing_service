package com.example.registerloginexample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {
    public String userID;
    private EditText et_id;
    private Button btn_rental, btn_return;
    private Button btn_bluetooth;
    fragment_home homefragment;
    fragment_rain rainfragment;

    fragment_siren sirenfragment;
    fragment_user userfragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        homefragment = new fragment_home();
        rainfragment = new fragment_rain();

        sirenfragment = new fragment_siren();
        userfragment = new fragment_user();

        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, homefragment).commit();
        NavigationBarView navigationBarView = findViewById(R.id.bottom_navigationview);

        navigationBarView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, homefragment).commit();
                        Intent intent = getIntent();
                        userID = intent.getStringExtra("userID");
                        Intent intent1 = new Intent(MainActivity.this,homefragment.getClass());
                        intent1.putExtra("userID",userID);
                        startActivity(intent1);
                        return true;
                    case R.id.rain:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, rainfragment).commit();
                        return true;
                    case R.id.siren:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, sirenfragment).commit();
                        return true;
                    case R.id.btn_user:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, userfragment).commit();
                        return true;
                }
                return false;
            }

        });





    }
}