package com.example.registerloginexample;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;

public class ConnecteActivity extends AppCompatActivity {
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private ConnectedThread connectedThread;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);

        textView = findViewById(R.id.textView);
        Intent intent = getIntent(); //메인액티비티에서 넘겨준 데이터 추출하기위해
        if(intent != null) {
            String sAddress = intent.getStringExtra("address"); //넘어온 주소, 이름 추출
            String sName = intent.getStringExtra("name");

            if(!sAddress.isEmpty()) { //잘 넘어왔으면
                bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(sAddress); //주소를가지고 리모트디바이스 찾아옴
                if(device == null) { //연결할수 없으면 아래실행
                    Toast.makeText(getApplicationContext(), "해당기기가 없습니다.", Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }
                connectToDevice(device); //찾아온 기기가 있으면 연결
            }
        }
    } // onCreate

    private Handler bluetoothHandler = new Handler(Looper.getMainLooper()){
        public void handleMessage(Message msg){ //이벤트 처리기 역할, 서버스레드에서 날린 메시지가 도착
            String readMessage = null;
            readMessage = new String((byte[]) msg.obj, StandardCharsets.UTF_8);
            readMessage = readMessage.trim();
            if(msg.what == ConnectedThread.BT_MESSAGE_READ){

                switch(readMessage) { //메시지 종류에 따라서 텍스트뷰에 뿌림
                    case "u": case "U": readMessage = "앞으로 이동"; break;
                    case "l": case "L": readMessage = "왼쪽으로 이동"; break;
                    case "r": case "R": readMessage = "오른쪽으로 이동"; break;
                    case "d": case "D": readMessage = "뒤로 이동"; break;
                    case "s": case "S": readMessage = "중지"; break;
                    default: readMessage = "이동 오류";
                }
            }
            textView.setText(readMessage);
        }
    };

    private void connectToDevice(BluetoothDevice device) {
        textView.setText("연결중...");
        if(!bluetoothAdapter.isEnabled()) { //활성화 안되어있으면
            Toast.makeText(this, "블루투스가 활성화되어 있지 않습니다.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String sName = device.getName();

        if(bluetoothAdapter.isDiscovering()) //찾는거 중단
            bluetoothAdapter.cancelDiscovery();

        try {
            if (bluetoothSocket != null)
                bluetoothSocket.close(); //소캣미리 생성되어있으면 닫음
            bluetoothSocket = device.createRfcommSocketToServiceRecord(ConnectedThread.BLUETOOTH_UUID_SPP); //uuid 사용해서 생성. 프로파일 중요
            bluetoothSocket.connect(); //연결
            textView.setText("연결 시도 : " + sName);
            if(connectedThread != null) //생성이 되어있으면 취소
                connectedThread.cancel();
            connectedThread = new ConnectedThread(bluetoothSocket, bluetoothHandler);//쓰레드생성해서 통신
            connectedThread.start(); //쓰레드 클래스의 런 호출
            textView.setText("연결 성공 : " + sName);
        } catch(Exception e) {
            textView.setText("연결 실패 : " + sName);
            e.printStackTrace();
            try {
                if (bluetoothSocket != null) {
                    bluetoothSocket.close();
                    bluetoothSocket = null;
                }
            } catch(Exception e1) {
                e1.printStackTrace();
            }
            finish();
        }
    } // connectToDevice

    public void onClickMove(View v) { //버튼 클릭시
        if(connectedThread == null) {
            Toast.makeText(this, "연결되지 않은 상태입니다.", Toast.LENGTH_LONG).show();
            return;
        }

        int id = v.getId(); //아이디 읽어서 저장
        String sendData = ""; //아두이노로 보낼 데이터 저장
        switch(id) {
            case R.id.imageButtonDown :
                sendData = "D";
                break;
            case R.id.imageButtonUp :
                sendData = "U";
                break;
            case R.id.imageButtonLeft :
                sendData = "L";
                break;
            case R.id.imageButtonRight:
                sendData = "R";
                break;
            default:
                sendData = "S";
                break;
        }
        connectedThread.write(sendData); //데이터 전송
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(connectedThread != null)
            connectedThread.cancel(); //이액티 종료시 쓰레드종료
    }
} // class